var Name=document.getElementById("name");
var Email=document.getElementById("Email");
var Phone=document.getElementById("Phone");
var Age=document.getElementById("age");
var password=document.getElementById("password");
var Repassword=document.getElementById("Repassword");


document.addEventListener("DOMContentLoaded", function() {
    fetchMeals();
});

let search = document.getElementById("search");

// Function to handle side nav
function toggleNav() {
    const $sideNav = $(".sidenav-menu");
    const currentLeft = $sideNav.css("left");

    if (currentLeft === "-256.562px") {
        $sideNav.animate({ left: 0 }, 1000);
    } else {
        $sideNav.animate({ left: '-256.562px' }, 1000);
    }
  
}
$("#toggleSideNav").click(toggleNav);

function closeSideNav() {
    const $sideNav = $(".sidenav-menu");
    $sideNav.animate({ left: '-256.562px' }, 1000);
}

function fetchMeals() {
    $.ajax({
        url: "https://www.themealdb.com/api/json/v1/1/search.php?s=",
        method: "GET",
        success: function(data) {
            var meals = data.meals;
            DisplayMeals(meals);
        },
        error: function(error) {
            console.error("Error fetching meals:", error);
        }
    });
}

function DisplayMeals(meals) {
    var container = "";
    for (let i = 0; i < meals.length; i++) {
        container += `
            <div class="col-md-3">
                <div onclick="GetMealDetails('${meals[i].idMeal}')" class="meal rounded-2 overflow-hidden position-relative cursor">
                    <img src="${meals[i].strMealThumb}" class="w-100">
                    <div class="layer position-absolute text-black d-flex align-items-center">
                        <h3>${meals[i].strMeal}</h3>
                    </div>
                </div>
            </div>
        `;
    }
    $("#rowData").html(container);
}

function GetMealDetails(idMeal) {
    $.ajax({
        url: `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${idMeal}`,
        method: "GET",
        success: function(data) {
            var meal = data.meals[0];
            displayMealDetails(meal);
        },
        error: function(error) {
            console.error("Error fetching meal details:", error);
        }
    });
}

function displayMealDetails(meal) {
    var ingredients = [];

    for (let i = 1; i <= 20; i++) {
        if (meal[`strIngredient${i}`]) {
            var ingredient = meal[`strIngredient${i}`].trim();
            var measure = meal[`strMeasure${i}`].trim();
            ingredients.push(`<li class="ingredient-item">${measure} ${ingredient}</li>`);
        } else {
            break;
        }
    }

    var mealDetailsHTML = `
        <div class="col-md-4">
            <img src="${meal.strMealThumb}" class="w-100 rounded-2">
            <h3>${meal.strMeal}</h3>
        </div>
        <div class="col-md-8 mb-5 mt-0">
            <h2>Instructions</h2>
            <p>${meal.strInstructions}</p>
            <h3> <span>Area:</span> ${meal.strArea}</h3>
            <h3> <span>Category:</span> ${meal.strCategory}</h3>
            <h3><span>Ingredients:</span>
                <ul class="list-unstyled d-flex g-3 flex-wrap">
                    ${ingredients.join("")}
                </ul>
            </h3>
            <h3><span>Tags:</span>
                <ul >
                    ${meal.strTags ? meal.strTags.split(",").map(tag => `<li class="tag">${tag.trim()}</li>`).join("") : ""}
                </ul>
            </h3>
            <a target="_blank" href="${meal.strSource}" class="btn btn-success">Source</a>
            <a target="_blank" href="${meal.strYoutube}" class="btn btn-danger">Youtube</a>
        </div>
    `;

    $("#mealDetailsRow").html(mealDetailsHTML);
    $("#mealDetailsContainer").show();
    $("#rowData").html("");
}

$(document).on("click", ".meal", function() {
    var mealID = $(this).data("idMeal");
    GetMealDetails(mealID);
});

function sarchinputs() {
    search.innerHTML = `
        <div class="row py-5">
            <div class="col-md-6">
                <input type="text" placeholder="Search By Name" onkeyup="SearchByName(this.value)" class="form-control bg-transparent text-white">
            </div>
            <div class="col-md-6">
                <input type="text" placeholder="Search By First letter" onkeyup="SearchByFirstletter(this.value)" class="form-control bg-transparent text-white">
            </div>
        </div>
    `;
    $("#rowData").html("");
    closeSideNav();
}

function SearchByName(name) {
    $.ajax({
        url: `https://www.themealdb.com/api/json/v1/1/search.php?s=${name}`,
        method: "GET",
        success: function(response) {
            if (response.meals) {
                DisplayMeals(response.meals);
            } else {
                DisplayMeals([]);
            }
        },
        error: function(error) {
            console.error("Error fetching meals:", error);
            DisplayMeals([]);
        }
    });
}

function SearchByFirstletter(letter) {
    if (letter.length === 1) {
        $.ajax({
            url: `  https://www.themealdb.com/api/json/v1/1/search.php?f=${letter}`,
            method: "GET",
            success: function(response) {
                if (response.meals) {
                    DisplayMeals(response.meals);
                } else {
                    DisplayMeals([]);
                }
            },
            error: function(error) {
                console.error("Error fetching meals:", error);
                DisplayMeals([]);
            }
        });
    }
}

function GetCategory()
{
    closeSideNav();

    $.ajax({
        url:"https://www.themealdb.com/api/json/v1/1/categories.php",
        method:"GET",
        success:function(response)
        {
            if(response.categories)
            {
                    DisplayCategories(response.categories)
            }
        },
        error: function(error) {
            console.error("Error fetching Categories:", error);   
        }

    })
}
function DisplayCategories(cat)
{
    var container="";
    for(let i=0;i<cat.length;i++)
        {
            container+=`
            <div class="col-md-3">
            <div  onclick="Getcategorymeals('${cat[i].strCategory}')" class="meal position-relative overflow-hidden rounded-2 cursor">
                <img src="${cat[i].strCategoryThumb}" class="w-100"> 
                <div class="layer position-absolute text-center text-black p-2" >
                    <h3 c>${cat[i].strCategory}</h3>
                    <p>${cat[i].strCategoryDescription.split(" ").slice(0,25).join(" ")}</p>
                </div>
            </div>
        </div>
          `
        }
        $("#rowData").html(container);
}

function Getcategorymeals(catogory)
{
    $.ajax({
        url:`https://www.themealdb.com/api/json/v1/1/filter.php?c=${catogory}`,
        method:"GET",
        success:function(response)
        {
            if(response.meals)
            {
                    DisplayMeals(response.meals.slice(0, 20));
            }
        },
        error: function(error) {
            console.error("Error fetching Categories:", error);   
        }

    })


    
}


function GetArea()
{
    closeSideNav();

    $.ajax({
        url:"https://www.themealdb.com/api/json/v1/1/list.php?a=list",
        method:"GET",
        success:function(response)
        {
            if(response.meals)
            {
                DisplayArea(response.meals.slice(0, 20))
            }
        },
        error: function(error) {
            console.error("Error fetching Categories:", error);   
        }

    })
}
function DisplayArea(arr)
{
    var container="";
    for(let i=0;i<arr.length;i++)
        {
            container+=`    
             <div class="col-md-3">
             <div  onclick="GetAreameals('${arr[i].strArea}')" class="text-center rounded-2 cursor">
                <i class="fa-solid fa-house-laptop fa-4x text-white"></i>
                <h3 class="text-white">${arr[i].strArea}</h3>
            </div>
        </div>
                 `
        }
        $("#rowData").html(container);
}

function GetAreameals(area)
{
    $.ajax({
        url:`https://www.themealdb.com/api/json/v1/1/filter.php?a=${area}`,
        method:"GET",
        success:function(response)
        {
            if(response.meals)
            {
                    DisplayMeals(response.meals.slice(0, 20));
            }
        },
        error: function(error) {
            console.error("Error fetching Area:", error);   
        }

    })


    
}

function GetIngredients()
{
    closeSideNav();

    $.ajax({
        url:"https://www.themealdb.com/api/json/v1/1/list.php?i=list",
        method:"GET",
        success:function(response)
        {
            if(response.meals)
            {
                DisplayIngredients(response.meals.slice(0, 20))
            }
        },
        error: function(error) {
            console.error("Error fetching Categories:", error);   
        }

    })
}
function DisplayIngredients(arr)
{
    var container="";
    for(let i=0;i<arr.length;i++)
        {
            container+=`    
             <div class="col-md-3">
             <div  onclick="GetIngredientsmeals('${arr[i].strIngredient}')" class="text-center text-white rounded-2 cursor">
                       <i class="fa-solid fa-drumstick-bite fa-4x"></i>
                        <h3>${arr[i].strIngredient}</h3>
                        <p>${arr[i].strDescription.split(" ").slice(0,20).join(" ")}</p>
             </div>
        </div>
                 `
        }
        $("#rowData").html(container);
}

function GetIngredientsmeals(ingredient)
{
    $.ajax({
        url:`https://www.themealdb.com/api/json/v1/1/filter.php?i=${ingredient}`,
        method:"GET",
        success:function(response)
        {
            if(response.meals)
            {
                    DisplayMeals(response.meals.slice(0, 20));
            }
        },
        error: function(error) {
            console.error("Error fetching Ingredient:", error);   
        }

    }) 
}

var allRegex = {
    name: /^[a-zA-Z ]+$/,
    Email: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    Phone: /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/,
    age: /^(0?[1-9]|[1-9][0-9]|[1][1-9][1-9]|200)$/,
    password: /^(?=.*\d)(?=.*[a-z])[0-9a-zA-Z]{8,}$/
};

function validateInput(input, regex) {
    if (!regex) return false;  // Handle undefined regex

    const value = input.value.trim();
    const isValid = regex.test(value);
    const alertMessage = input.nextElementSibling;

    if (alertMessage) {
        if (!isValid && value !== "") {
            alertMessage.style.display = 'block';
            input.classList.add('is-invalid');
        } else {
            alertMessage.style.display = 'none';
            input.classList.remove('is-invalid');
        }
    }

    return isValid;
}



function checkAllValidations() {
    const inputs = document.querySelectorAll('#rowData .form-control');
    let allValid = true;

    inputs.forEach(input => {
        const id = input.id;
        let isValid;
        if (id !== 'Repassword') {
            isValid = validateInput(input, allRegex[id]);
        } else {
            const passwordInput = document.getElementById('password');
            isValid = input.value === passwordInput.value;
            const alertMessage = input.nextElementSibling;
            if (!isValid && input.value !== "") {
                alertMessage.style.display = 'block';
                input.classList.add('is-invalid');
            } else {
                alertMessage.style.display = 'none';
                input.classList.remove('is-invalid');
            }
        }
        if (!isValid) {
            allValid = false;
        }
    });

    document.getElementById('submitBtn').disabled = !allValid;
}



function showContacts() {
    closeSideNav();
    const contactFormHTML = `
        <div class="vh-100 d-flex justify-content-center align-items-center">
            <div class="container w-75 text-center">
                <div class="row g-4">
                    <div class="col-md-6">
                        <input type="text" placeholder="Enter Your Name" class="form-control" id="name">
                        <div class="invalid-feedback">Special characters and numbers not allowed</div>
                    </div>
                    <div class="col-md-6">
                        <input type="email" placeholder="Enter Your Email" class="form-control" id="Email">
                        <div class="invalid-feedback"> Email not valid *exemple@yyy.zzz</div>
                    </div>
                    <div class="col-md-6">
                        <input type="text" placeholder="Enter Your Phone" class="form-control" id="Phone">
                        <div class="invalid-feedback">Enter valid Phone Number</div>
                    </div>
                    <div class="col-md-6">
                        <input type="number" placeholder="Enter Your Age" class="form-control" id="age">
                        <div class="invalid-feedback">Enter valid age</div>
                    </div>
                    <div class="col-md-6">
                        <input type="password" placeholder="Enter Your password" class="form-control" id="password">
                        <div class="invalid-feedback">Enter valid password *Minimum eight characters, at least one letter and one number:*</div>
                    </div>
                    <div class="col-md-6">
                        <input type="password" placeholder="Repassword" class="form-control" id="Repassword">
                        <div class="invalid-feedback">Passwords do not match</div>
                    </div>
                </div>
                <button id="submitBtn" disabled class="btn btn-outline-danger px-2 mt-3">Submit</button>
            </div>
        </div>
    `;

    $("#rowData").html(contactFormHTML);

    // Add event listeners for validation
    const inputs = document.querySelectorAll('#rowData .form-control');
    inputs.forEach(input => {
        input.addEventListener('keyup', function() {
            const id = input.id;
            let isValid;
            if (id !== 'Repassword') {
                isValid = validateInput(input, allRegex[id]);
            } else {
                const passwordInput = document.getElementById('password');
                isValid = input.value === passwordInput.value;
                const alertMessage = input.nextElementSibling;
                if (!isValid && input.value !== "") {
                    alertMessage.style.display = 'block';
                    input.classList.add('is-invalid');
                } else {
                    alertMessage.style.display = 'none';
                    input.classList.remove('is-invalid');
                }
            }
            checkAllValidations();
        });
    });
}








